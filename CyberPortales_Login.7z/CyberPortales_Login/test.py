from selenium import webdriver
ff=webdriver.Firefox()
ff.get(u'http://www.eltiempo.com/colombia')
assert 'Colombia' in ff.title
ff.quit()