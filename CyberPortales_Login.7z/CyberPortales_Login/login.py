from selenium  import  webdriver
from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support.select import Select

import unittest
import time

class loginTest(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.get(u'https://cybersecurity-telefonica.e-paths.com/')
        self.driver.maximize_window()

    def test_Login(self):
        driver=self.driver
        window_before = driver.window_handles[0]
        cyber_userName = "johanjavier.pizarro@11paths.com"
        cyber_password = "Telefonica_1988"
        userNameFieldID = "username"
        passwordFieldID = "password"
        buttonLoginFieldID = "8763762a-6816-4b8b-ab9b-65d5adb99422"
        bienvenidoTittleID = "07a9abbc-6645-4b29-9bbf-2efd99984ac4"
        menuGesiVulneraID= "vms-b4dc0ebe-5653-4c1b-8b10-e6502701dabb"
        menuVulneraXpath="html/body/div[1]/div/header/ul/li[2]/a"
        menuActivosXpath="html/body/div[1]/div/header/ul/li[3]/a"  #//a[contains(@href, 'Activos')][2]
        activoTituloXpath="html/body/div[1]/div/div/div/div/h1"
        logoutXpath="html/body/div[1]/div/header/div[1]/li[3]/a"

        userNameFieldElement = WebDriverWait(driver, 10).until(lambda driver: driver.find_element_by_id(userNameFieldID))
        passwordFieldElement = WebDriverWait(driver, 10).until(lambda driver: driver.find_element_by_id(passwordFieldID))
        buttonLoginFielElement = WebDriverWait(driver, 10).until( lambda driver: driver.find_element_by_id(buttonLoginFieldID))


        userNameFieldElement.clear()
        userNameFieldElement.send_keys(cyber_userName)

        passwordFieldElement.clear()
        passwordFieldElement.send_keys(cyber_password)
        buttonLoginFielElement.click()

        WebDriverWait(driver, 30)
        #home_tittle=WebDriverWait(driver,10).until(lambda driver: )
        assert 'servicios de seguridad' in driver.title
        #Ingreso al menu Gestion de Vulnerabilidades
        menuGesiVulneraFieldElement=WebDriverWait(driver,30).until(lambda  driver: driver.find_element_by_id(menuGesiVulneraID))
        menuGesiVulneraFieldElement.click()

        window_after = driver.window_handles[1]
        driver.switch_to_window(window_after)

        time.sleep(10)


        WebDriverWait(driver,10).until(lambda  driver:driver.find_element_by_xpath(menuVulneraXpath))


       # assert 'Vulnerabilidades'in menuVulneraFieldElement.get_attribute("name")


        menuActivosFieldElement = WebDriverWait(driver, 60).until( lambda driver: driver.find_element_by_xpath(menuActivosXpath))
        menuActivosFieldElement.click()

        time.sleep(10)


        WebDriverWait(driver,20).until(lambda  driver: driver.find_element_by_xpath(activoTituloXpath))

        logout = WebDriverWait(driver, 30).until(lambda driver: driver.find_element_by_xpath(logoutXpath))
        logout.click()



    def tearDown(self):
       self.driver.quit()


if __name__ == "__main__":
    unittest.main()